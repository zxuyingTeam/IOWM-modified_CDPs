## Code For CHW (93.79%)
Data can be found in [CASIA_HWDB](http://www.nlpr.ia.ac.cn/databases/handwriting/Home.html)


### Environment configurations 

- Linux: Ubuntu 18.04

- cuda10.0 & cudnn10.1

- Python 3.7.3

- torch 1.5.0 (pytorch)

- torchvision 0.6.0

- numpy 1.16.4

- scipy 1.3.0

