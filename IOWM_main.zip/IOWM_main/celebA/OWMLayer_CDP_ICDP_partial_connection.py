# -*- coding: utf-8 -*-
import torch
import torch.nn as nn
from torch.autograd import Variable
import numpy as np
import scipy.io as scio
import sys

dtype = torch.FloatTensor

class IOWMLayer_partial:

    def __init__(self, shape_list, alpha, l2_reg_lambda, train_context, contextual_information=1, ICDP=True, partial=0, args=None):
        """
        :param shape_list: neurons
        :param alpha: the regularization parameter of projection
        :param l2_reg_lambda: the weight of loss regularization
        :param train_context:  bool,determine whether update the weight of encoder module
        :param contextual_information: 0-Embedding,1-orthogonal
        :param ICDP: bool,True-no activation
        :param partial: 0-first partial,1-second partial,2-third partial
        """
        contex_size = int(shape_list[1][0])
        self.class_num = int(shape_list[1][1])
        if args:
            self.device = torch.device(args.device)
        else:
            self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.ICDP = ICDP
        self.partial = partial
        self.contextual_information = contextual_information
        self.w_in = self.get_weight(shape_list[0], requires_grad=False)
        # the weight of classifer
        self.w1 = self.get_weight(shape_list[1], zeros=True)
        with torch.no_grad():
            self.P1 = Variable((1.0 / alpha[0]) * torch.eye(int(shape_list[1][0])).type(dtype)).to(self.device)

        # the encoder vector
        if self.contextual_information == 0:
            # embedding vector
            wordvet = scio.loadmat('wordvet.mat')
            # the word_vec shape is:(40, 200)
            self.word_vec = wordvet['wordvet']
        elif self.contextual_information == 1:
            # orthogonal vector
            self.word_vec = np.zeros((40, 200))
            for i in range(40):
                self.word_vec[i, i * 5:(i + 1) * 5] = [1] * 5
        # bool type,determine whether update the weight of encoder module
        self.train_context = train_context
        # the weight of encoder module
        # self.w_c = self.get_weight([self.word_vec.shape[1], contex_size], requires_grad=self.train_context)
        self.w_c = self.get_weight([self.word_vec.shape[1], contex_size], requires_grad=False)
        with torch.no_grad():
            self.P_c = Variable((1.0 / alpha[0]) * torch.eye(int(self.w_c.size(0))).type(dtype)).to(self.device)

        self.myAFun = nn.ReLU().to(self.device)
        self.criterion = nn.MSELoss().to(self.device)
        self.l2_reg_lambda = l2_reg_lambda

    def owm_learn(self, batch_x, batch_y, train=False, alpha_list=None, task_index=None, iowm=True,
                  partial_flag=True, encoder_lr=10.0):
        if partial_flag:
            # create index for the weight of encoder module
            self.idx = torch.zeros(self.w_c.shape).type(torch.int32)
            self.idx = self.idx.to(self.device)
            if self.partial == 0:
                for i in range(5):
                    index = torch.FloatTensor([1] * 800)
                    self.idx[task_index * 5 + i, i * 800:(i + 1) * 800] = index.type(torch.int32).to(self.device)
            elif self.partial == 1:
                lists = [0, 800, 1600, 2400, 3200, 4000]
                count = [0] * 5  # record the number of visits to the current location
                for i in range(5):
                    idx_tmp = np.arange(lists[i], lists[i + 1])  # continuous neurons
                    for j in range(i):
                        idx_tmp = np.hstack((idx_tmp, np.arange(lists[j] + count[j], lists[j + 1], 4)))
                        count[j] += 1  # add 1 represents the number of visits
                    for j in range(i + 1, 5):
                        idx_tmp = np.hstack((idx_tmp, np.arange(lists[j] + count[j], lists[j + 1], 4)))
                        count[j] += 1
                    idx_tmp = np.sort(idx_tmp)
                    index = torch.FloatTensor([1] * len(idx_tmp))
                    self.idx[task_index * 5 + i, idx_tmp] = index.type(torch.int32).to(self.device)
            # the index of partial connections
            self.wc = self.idx * self.w_c
            self.wc = Variable(self.wc.to(self.device), requires_grad=True)
        batch_x = torch.from_numpy(batch_x)
        batch_y = torch.from_numpy(batch_y)
        # the contextual information(contextual information)
        context_input = torch.from_numpy(self.word_vec[task_index, :])
        context_input = torch.unsqueeze(context_input, 0)  # add a dimension

        with torch.no_grad():
            labels = Variable(batch_y.type(dtype)).to(self.device)
            batch_x = Variable(batch_x.type(dtype)).to(self.device)
            context_input = Variable(context_input.type(dtype)).to(self.device)
        # compute the 2-norm of raws,the shape of norm_old is batch_x.shape[0]
        norm_old = torch.norm(batch_x, 2, 1)
        # the first layer doesn't update, so we don't add activation function
        if self.ICDP:
            y0 = batch_x.mm(self.w_in)
        else:
            y0 = self.myAFun(batch_x.mm(self.w_in))
        context = self.myAFun(context_input.mm(self.wc))
        batch_x = y0 * context
        # Ensure the 2-norm of each feature remains unchanged
        norm_batch_x = torch.norm(batch_x, 2, 1)
        if 0 in norm_batch_x:
            print('Train stage norm_batch_x exits zero element!!!')
            sys.exit(0)
        test_NaN = torch.isnan(norm_batch_x).type(torch.float)
        if torch.sum(test_NaN) > 0:
            print('Train stage exits NaN!!!')
            sys.exit(0)

        g = (norm_old / (norm_batch_x + 0)).repeat(batch_x.size(1), 1).type(dtype).to(self.device)
        batch_x.data *= g.data.t()
        # the output of classifier
        y_pred = batch_x.mm(self.w1)
        labels = labels.unsqueeze(1)

        if train:
            loss = self.criterion(y_pred, labels) + self.l2_reg_lambda * (torch.norm(context, p=1))
            loss.backward()
            # determine whether update the weight of encoder module
            if self.train_context:
                self.P_c = self.learning(context_input, self.P_c, self.wc, alpha_list[0]*encoder_lr, alpha_list[1],
                                         encoder=True, iowm=iowm)
            self.P1 = self.learning(batch_x, self.P1, self.w1, alpha_list[0], alpha_list[2], encoder=False, iowm=iowm)
        else:
            predicted = torch.round(y_pred.data)
            predicted = torch.squeeze(predicted, 1)
            correct = torch.eq(predicted.cpu(), batch_y).sum()
            return correct, batch_y.size(0)

    def learning(self, input_, Pro, weight, lr=0, alpha=1.0, encoder=True, iowm=True):
        r = torch.mean(input_, 0, True)
        k = torch.mm(Pro, torch.t(r))
        if iowm:
            tmp = Pro - torch.mm(k, torch.t(k)) / (alpha + torch.mm(r, k))
            Pro = tmp.detach()
        if encoder:
            weight.data -= (lr * self.idx) * torch.mm(Pro.data, weight.grad.data)
        else:
            weight.data -= torch.mm(Pro.data, weight.grad.data)
        weight.grad.data.zero_()
        return Pro

    def get_weight(self, shape, zeros=None, seed=0, requires_grad=True):
        if seed is not None:
            np.random.seed(seed)
        if zeros is None:
            # Xavier
            w = np.random.normal(0, np.sqrt(2.0 / sum(shape)), shape)
        else:
            w = np.zeros(shape)
        w = torch.from_numpy(w).type(dtype).to(self.device)
        return Variable(w, requires_grad=requires_grad)

